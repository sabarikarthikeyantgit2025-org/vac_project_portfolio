# AI Tools Used in the Capstone Project

**Student:** Syed Umar T  
**Course:** B.Tech Information Technology — Second Year  
**Project:** AI Portfolio Website Content Creator

## 1. Introduction

This project explores how artificial intelligence tools can assist in planning, writing, reviewing, and presenting the content of a personal portfolio website.

AI tools can help generate ideas and improve writing. However, their output must be checked by a human to ensure accuracy, originality, suitability, and responsible use.

This document records the tools considered for the project. The usage and evidence sections must reflect the work actually completed.

## 2. AI Tools

### Tool 1: ChatGPT

**Purpose:** Planning the portfolio, drafting and refining website text, developing prompts, and preparing project documentation.

**Tasks:** Drafting portfolio descriptions, improving wording, organizing the case study, and planning verification activities.

**Human review:** Check that descriptions match my actual education, skills, projects, and completed activities. Remove unsupported claims.

**Evidence to retain:** Prompts used, original drafts, revised text, and examples of corrections.

**Usage status:** Used during project development. Specific prompts and outputs should be recorded in the prompt library.

### Tool 2: Google Gemini

**Planned purpose:** Obtain an alternative review of portfolio wording, clarity, structure, and possible improvements.

**Planned task:** Ask Gemini to review a draft and suggest improvements without inventing achievements or skills.

**Evidence to retain:** The prompt, response, review notes, and any changes accepted or rejected.

**Usage status:** Record as completed only after the tool has actually been used and its output reviewed.

### Tool 3: AI Image Generation

**Purpose:** Create a visual banner for the personal portfolio website.

**Task completed:** Generated a portfolio banner containing my name, educational details, technology interests, and the phrase “LEARN | BUILD | GROW.”

**Human review:** Checked that the banner displayed correctly on the website and that its content was relevant to the portfolio.

**Evidence:** The generated image, `portfolio-banner.png`, is stored in the project repository and displayed on the homepage.

**Limitations:** AI-generated graphics may contain inaccurate text or visual inconsistencies. The resulting image should be checked before publication.

**Usage status:** Used.

### Tool: Grammarly

**Purpose:** To review the grammar, clarity, and readability of the About Me section on my portfolio website.

**Content Tested:** The 69-word About Me section describing my education, technical skills, interests, and career goals.

**Results:**
- Grammarly displayed an overall writing score of 91.
- The grammar review showed no remaining grammar suggestions.
- Grammarly identified two clarity suggestions for further review.
- The text was reviewed, and the suggestions could be considered before making any changes.

**Human Review:** The original meaning and personal information were retained. Suggestions were to be evaluated carefully rather than accepted automatically.

**Evidence:** Screenshot of the Grammarly review showing the score and suggestion counts.

**Limitation:** Grammarly's score is an automated writing assessment. It does not verify the accuracy of personal claims or technical skills.
### Tool: Microsoft Copilot

**Purpose:** To review the project description for clarity, completeness, and accuracy.

**Task Performed:** Submitted the description of my AI Portfolio Website Content Creator project and asked Copilot to identify strengths, suggest improvements, and flag claims requiring verification.

**Results:**
1. Copilot identified clear project scope and transparent acknowledgement of AI usage as strengths.
2. It recommended explaining the project's purpose more precisely, describing my personal contributions, and documenting the AI workflow.
3. It suggested the alternative title "AI-Assisted Portfolio Website" because the current project description focuses on AI-assisted content improvement rather than an automated content-generation system.
4. It identified claims that should be supported by evidence, including website implementation, GitHub Pages deployment, website sections, and AI tool usage.

**Human Review:** The suggestions were reviewed for relevance. The project title and description should accurately represent the actual website and its functionality. No feature or result should be claimed without evidence.

**Evidence:** Saved Copilot response containing the review, suggested description, and verification checklist.

**Limitation:** Copilot's feedback is an AI-generated review, not independent verification that the project features work correctly.

## 3. Tool Comparison

| Tool | Intended use | Evidence required |
|---|---|---|
| ChatGPT | Content drafting and prompt development | Prompts, drafts, revisions |
| Google Gemini | Alternative review and suggestions | Prompt, response, review notes |
| Canva AI | AI-assisted visual design | Design evidence and prompt |
| Grammarly | Grammar and readability review | Suggestions and corrections |

## 4. Actual Usage and Evidence Log

| Tool | Task completed | Evidence | Result |
|---|---|---|---|
| ChatGPT | Assisted with portfolio content, project documentation, prompt development, and revisions. | Conversation records and saved project documents. | Used; individual examples should be documented in the prompt library. |
| Google Gemini | Reviewed portfolio wording for clarity, grammar, organization, and claims requiring evidence. | Gemini review response containing suggested revisions and recommendations. | Used; suggestions require human review before acceptance. |
| Canva AI | AI-assisted visual design. | Evidence to be added if Canva AI is used. | Pending confirmation. |
| Grammarly | Grammar and readability review. | Evidence to be added if Grammarly is used. | Pending confirmation. |

### Google Gemini Review Findings

Gemini reviewed a draft describing my education, technical skills, and capstone project.

The main suggestions were:
- Present technical skills in a clearly labeled list.
- Use concise wording to explain the capstone project.
- Support skill claims with examples of actual work.
- Document the project workflow and AI-assisted revisions.

### Human Review of Gemini Suggestions

The feedback was reviewed rather than accepted automatically.

- The suggested technical skills format can be used if it matches the portfolio layout.
- Wording changes should preserve my actual educational status and experience.
- I will not claim completed coursework, additional projects, or expertise unless these are accurate.
- The portfolio website and its source code provide evidence of my HTML and CSS work. My Python skill level should be represented honestly.

### Evidence Retention

The Gemini response has been provided for this project review. A screenshot or saved copy should be retained in the project evidence folder if required for submission.

The remaining tools will be marked as used only after their actual use is confirmed and documented.

## 5. Responsible Use

The following principles guide the use of AI in this project:

- Verify personal and technical information before publishing.
- Do not invent skills, achievements, experience, or project results.
- Review generated text and make appropriate human edits.
- Avoid sharing passwords, private contact details, or other sensitive information.
- Check image licensing and usage conditions before publishing visual assets.
- Keep records of significant AI-generated content and corrections.
- Disclose limitations and distinguish planned activities from completed activities.

## 6. Limitations

AI-generated content may contain factual errors, generic descriptions, repetitive wording, or unsupported claims. AI tools may also provide different suggestions for the same prompt.

For these reasons, AI output is treated as a draft rather than an authoritative source. Human review and testing remain necessary.

## 7. Conclusion

AI tools can support portfolio content creation, writing review, and visual planning. Their value in this project will be evaluated through documented prompts, actual outputs, human corrections, and verification results.

The final report will identify which tools were actually used, what each contributed, and what limitations were observed.
